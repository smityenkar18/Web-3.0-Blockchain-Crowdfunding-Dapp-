import crowdFunding from "./CrowdFunding.json";

//Crowd Funding MARKETPLACE
export const CrowdFundingAddress = "0x5FbDB2315678afecb367f032d93F642f64180aa3";

export const CrowdFundingABI = crowdFunding.abi;